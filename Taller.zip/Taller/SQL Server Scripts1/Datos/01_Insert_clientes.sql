INSERT INTO Clientes VALUES 
('12345678A', 'Juan', 'P�rez', 'Garc�a', 'Calle Falsa 123', 'Madrid', '28001', '911234567', 'juan@example.com', 'doc1.pdf'),
('87654321B', 'Mar�a', 'L�pez', 'Mart�nez', 'Avenida Siempre Viva 742', 'Barcelona', '08001', '921234567', 'maria@example.com', 'doc2.pdf'),
('11223344C', 'Carlos', 'S�nchez', 'Fern�ndez', 'Plaza Mayor 5', 'Valencia', '46001', '931234567', 'carlos@example.com', 'doc3.pdf'),
('44332211D', 'Ana', 'G�mez', 'Rodr�guez', 'Calle Sol 25', 'Sevilla', '41001', '941234567', 'ana@example.com', 'doc4.pdf');
