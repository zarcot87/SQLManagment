INSERT INTO Facturas (ClienteNIF, Matricula, Kilometraje, ImporteSinIVA) VALUES 
('12345678A', '1234ABC', 80000, 130),
('87654321B', '5678DEF', 50000, 195);