INSERT INTO Reparaciones (Matricula, Descripcion, ValorMateriales, Horas) VALUES 
('1234ABC', 'Cambio de aceite', 30, 1),
('1234ABC', 'Cambio de frenos', 100, 2),
('5678DEF', 'Revisi�n general', 50, 1.5),
('5678DEF', 'Sustituci�n de bater�a', 120, 1);