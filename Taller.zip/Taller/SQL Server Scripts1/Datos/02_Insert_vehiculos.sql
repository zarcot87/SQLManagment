INSERT INTO Vehiculos VALUES 
('1234ABC', 'Toyota', 'Corolla', 2015, 80000, 'Gasolina', 'Manual', 110, '12345678A'),
('5678DEF', 'Ford', 'Fiesta', 2018, 50000, 'Diesel', 'Automatico', 90, '87654321B'),
('9012GHI', 'Tesla', 'Model 3', 2022, 15000, 'Electrico', 'Automatico', 250, '11223344C'),
('3456JKL', 'Honda', 'Civic', 2020, 30000, 'Hibrido', 'Manual', 150, '44332211D');
