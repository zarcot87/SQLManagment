USE [Taller]
GO

/****** Object:  UserDefinedDataType [dbo].[Combustible]    Script Date: 1/4/2025 8:40:13 ******/
CREATE TYPE [dbo].[Combustible] FROM [varchar](20) NOT NULL
CREATE TYPE [dbo].[cambio] FROM [varchar](10) NOT NULL
CREATE TYPE [dbo].[Cp] FROM [char](5) NOT NULL
CREATE TYPE [dbo].[enlace] FROM [varchar](255) NULL
CREATE TYPE [dbo].[Matricula_tipo] FROM [char](7) NOT NULL
CREATE TYPE [dbo].[nif_tipo] FROM [char](9) NOT NULL
CREATE TYPE [dbo].[Nombre_Apellido] FROM [varchar](50) NOT NULL
CREATE TYPE [dbo].[TextoExtenso] FROM [varchar](100) NOT NULL
CREATE TYPE [dbo].[TextoM] FROM [varchar](50) NOT NULL

GO