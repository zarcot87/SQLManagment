CREATE TABLE Vehiculos (
    Matricula Matricula_tipo PRIMARY KEY,
    Marca TextoM NOT NULL,
    Modelo textoM DEFAULT 'Toyota' NOT NULL,
    AnioMatriculacion INT NOT NULL,
    Kilometraje INT NOT NULL,
    TipoCombustible Combustible CHECK (TipoCombustible IN ('Gasolina', 'Diesel', 'Hibrido', 'Electrico')) NOT NULL,
    TipoCambio Cambio CHECK (TipoCambio IN ('Manual', 'Automatico')) NOT NULL,
    Potencia INT NOT NULL,
    ClienteNIF nif_tipo,
    FOREIGN KEY (ClienteNIF) REFERENCES Clientes(NIF)
);

