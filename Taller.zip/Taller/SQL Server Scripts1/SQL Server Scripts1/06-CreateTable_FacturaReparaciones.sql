CREATE TABLE FacturaReparaciones (
    IdFactura INT,
    IdReparacion INT,
    PRIMARY KEY (IdFactura, IdReparacion),
    FOREIGN KEY (IdFactura) REFERENCES Facturas(IdFactura),
    FOREIGN KEY (IdReparacion) REFERENCES Reparaciones(IdReparacion)
);