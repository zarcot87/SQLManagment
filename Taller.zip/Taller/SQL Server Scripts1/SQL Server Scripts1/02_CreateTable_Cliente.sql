CREATE TABLE Clientes (
    NIF  nif_tipo PRIMARY KEY,
    Nombre Nombre_Apellido,
    Apellido1 Nombre_Apellido,
    Apellido2 Nombre_Apellido,
    Direccion TextoExtenso,
    Poblacion VARCHAR(50) NOT NULL,
    CP Cp DEFAULT '08191',
    Telefono nif_tipo,
    Email TextoExtenso,
    DatosAdjuntos enlace -- Enlace a PDF
);

SELECT * FROM sys.types WHERE is_user_defined = 1;
