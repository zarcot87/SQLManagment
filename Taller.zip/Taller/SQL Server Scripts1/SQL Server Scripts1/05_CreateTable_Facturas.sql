CREATE TABLE Facturas (
    IdFactura INT IDENTITY PRIMARY KEY,
    FechaFactura DATE DEFAULT GETDATE(),
    ClienteNIF nif_tipo,
    Matricula Matricula_tipo,
    Kilometraje INT NOT NULL,
    ImporteSinIVA DECIMAL(10,2) NOT NULL,
    ImporteTotal AS (ImporteSinIVA + (ImporteSinIVA*0.21)),
    FOREIGN KEY (ClienteNIF) REFERENCES Clientes(NIF),
    FOREIGN KEY (Matricula) REFERENCES Vehiculos(Matricula)
);