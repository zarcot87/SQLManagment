CREATE TABLE Reparaciones (
    IdReparacion INT IDENTITY PRIMARY KEY,
    FechaReparacion DATE DEFAULT GETDATE(),
    Matricula Matricula_tipo,
    Descripcion enlace DEFAULT 'checkeo',
    ValorMateriales DECIMAL(10,2) NOT NULL,
    Horas DECIMAL(4,2) DEFAULT 0.5 CHECK (Horas >= 0.25),
    ImporteTotal AS ((Horas * 50) + ValorMateriales), -- C�lculo directo
    FOREIGN KEY (Matricula) REFERENCES Vehiculos(Matricula)
);
