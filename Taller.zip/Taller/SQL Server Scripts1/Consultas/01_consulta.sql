SELECT Matricula, SUM(ImporteTotal) AS TotalReparaciones 
FROM Reparaciones 
WHERE Matricula = '1234ABC'
GROUP BY Matricula;