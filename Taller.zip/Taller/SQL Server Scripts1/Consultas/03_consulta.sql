SELECT v.Matricula, v.Marca, v.Modelo
From vehiculos v
LEFT JOIN Reparaciones r ON v.Matricula = r.Matricula
Where r.Matricula IS NULL;