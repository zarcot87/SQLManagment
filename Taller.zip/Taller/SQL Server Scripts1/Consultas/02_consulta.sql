SELECT r.IdReparacion, r.Matricula, r.Descripcion, r.ImporteTotal
From Reparaciones r
LEFt JOIN FacturaReparaciones fr ON r.IdReparacion = fr.IdReparacion
WHERE fr.IdReparacion IS NULL;