CREATE PROCEDURE CrearFactura (@IdReparacion INT)
AS
BEGIN
    DECLARE @ClienteNIF CHAR(9), @Matricula CHAR(7), @Kilometraje INT, @ImporteSinIVA DECIMAL(10,2);
    
    SELECT @ClienteNIF = v.ClienteNIF, @Matricula = r.Matricula, @Kilometraje = v.Kilometraje, @ImporteSinIVA = r.ImporteTotal
    FROM Reparaciones r
    JOIN Vehiculos v ON r.Matricula = v.Matricula
    WHERE r.IdReparacion = @IdReparacion;
    
    INSERT INTO Facturas (ClienteNIF, Matricula, Kilometraje, ImporteSinIVA)
    VALUES (@ClienteNIF, @Matricula, @Kilometraje, @ImporteSinIVA);
    
    DECLARE @IdFactura INT = SCOPE_IDENTITY();
    INSERT INTO FacturaReparaciones VALUES (@IdFactura, @IdReparacion);
END;

EXEC CrearFactura @IDReparacion = ;